﻿using System;

namespace Campus_Security_Staffs_Management_System
{
    internal class LoginForm
    {
        public LoginForm()
        {
        }

        internal void Show()
        {
            //throw new NotImplementedException();
        }
    }
}