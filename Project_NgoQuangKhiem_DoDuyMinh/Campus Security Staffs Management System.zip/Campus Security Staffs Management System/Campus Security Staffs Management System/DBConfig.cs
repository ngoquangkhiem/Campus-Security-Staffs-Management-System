﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Campus_Security_Staffs_Management_System
{
    //internal class DBConfig
    //{
    //}
    public static class DBConfig
    {
        public static string ConnectionString = "server=192.168.1.13;user=manager;password=141102;database=staff_system;";
    }
}
